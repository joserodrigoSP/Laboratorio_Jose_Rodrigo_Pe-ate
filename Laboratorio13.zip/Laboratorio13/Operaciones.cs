class Operaciones{




}