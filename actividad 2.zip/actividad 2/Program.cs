﻿class Program{
static void Main(string[] args){

    int numeroMes;
    string entradaMes;
    string mes;
    Console.WriteLine("Ingrese el mes (1-12): ");
    entradaMes = Console.ReadLine();


   if(int.TryParse(entradaMes, out numeroMes)){

        Console.WriteLine($"Se convirtio '{entradaMes}' a '{numeroMes}'");
    }else{
        Console.WriteLine("Error: ingrese un número del 1 al 12");
  }
    
    switch(numeroMes){

        case 1:
        mes = "MES: enero";
        break; 

        case 2: 
        mes = "MES: febrero";
        break;

        case 3:
          mes = "MES: marzo";
        break;

        case 4:
         mes = "MES: abril";
        break;
        case 5:
         mes = "MES: mayo";
        break;
        case 6:
         mes = "MES: junio";
        break;
        case 7:
         mes = "MES: julio";
        break;
        case 8:
         mes = "MES: agosto";
        break;
        case 9:
         mes = "MES: septiembre";
        break;
        case 10:
         mes = "MES: octubre";
        break;
        case 11:
         mes = "MES: noviembre";
        break;
        case 12:
         mes = "MES: diciembre";
        break;
        default:
        mes = "error: Ingresar un numero del 1 al 12";

        break;

    }

    Console.WriteLine(mes);

    Console.WriteLine("Ejercicio 2");
    int A;
    int B;
    int C;
  
    Console.WriteLine("Ingrese un valor para el primer número: ");
    int.TryParse(Console.ReadLine(), out A);
  
    Console.WriteLine("Ingrese un valor para el segundo número: ");
    int.TryParse(Console.ReadLine(), out B);

    Console.WriteLine("Ingrese un valor para el tercer número: ");
    int.TryParse(Console.ReadLine(), out C);



    if(A>B){
        if(A>C){
            Console.WriteLine("Resultado: A es el numero mayor");
        }else {
            if(A==C){
            Console.WriteLine("Resultado: A y C son los numeros mayores");}else{
                if(C>A){
                    Console.WriteLine("Resultado: C  es el numero mayor");
                }
            }
        }

    }else {
        if(A==B){
            if(A>C){
                Console.WriteLine("Resultado: A y B son los numeros mayores");
            }else{
                if(A==C){
                    Console.WriteLine("Resultado: Los tres numeros son iguales");
                } else{
                     if(C>A){
                    Console.WriteLine("Resultado: C es el numero mayor");
                }
                }
            }

        }else{
            if(B>C){
                Console.WriteLine("Resultado: B es el numero mayor");
            }else{
                if(B==C){
                    Console.WriteLine("Resultado: B y C son los mayores");
                }else{  if(C>B){
                    Console.WriteLine("Resultado: C  es el numero mayor");
                }}
            }
        }
    }

    int mes2;
    int dia;
    Console.WriteLine("Ingrese numero de mes de nacimiento ");
    int.TryParse(Console.ReadLine(), out  mes2);
    Console.WriteLine("Cual es su dia de nacimiento?");
    int.TryParse(Console.ReadLine(), out dia);
// Aries
    if((dia>=21 && dia<=31)&&(mes2==3) || (dia>=1 && dia<=19)&&(mes2==4)){
        Console.WriteLine("Su signo del zodiaco es: Aries");
    }
 // Tauro
    if((dia>=20 && dia<=31)&&(mes2==4) || (dia>=1 && dia<=20)&&(mes2==5)){
        Console.WriteLine("Su signo del zodiaco es: Tauro");
    }
 // Geminis
    if((dia>=21 && dia<=31)&&(mes2==5) || (dia>=1 && dia<=20)&&(mes2==6)){
        Console.WriteLine("Su signo del zodiaco es: Geminis");
    }
//Cancer
    if((dia>=21 && dia<=31) && mes2==6 || (dia>=1 && dia<=22) && mes2==7){
        Console.WriteLine("Su signo del zodiaco es: cancer");
    }
//Leo
    if((dia>=23 && dia<=31) && mes2==7 || (dia>=1 && dia<=22) && mes2==8){
        Console.WriteLine("Su signo del zodiaco es: Leo");
    }
//Virgo 
    if((dia>=23 && dia<=31) && mes2==8 || (dia>=1 && dia<=22) && mes2==9){
        Console.WriteLine("Su signo del zodiaco es: virgo");
    }
//Libra 
    if((dia>=23 && dia<=31) && mes2==9 || (dia>=1 && dia<=22) && mes2==10){
        Console.WriteLine("Su signo del zodiaco es: Libra");
    }
//Escorpio 
    if((dia>=23 && dia<=31) && mes2==10 || (dia>=1 && dia<=21) && mes2==11){
        Console.WriteLine("Su signo del zodiaco es: Escorpio");
    }
//Sagitario 
    if((dia>=22 && dia<=31) && mes2==11 || (dia>=1 && dia<=21) && mes2==12){
        Console.WriteLine("Su signo del zodiaco es: Sagitario");
    }
//Capricornio
    if((dia>=22 && dia<=31) && mes2==12 || (dia>=1 && dia<=19) && mes2==1){
        Console.WriteLine("Su signo del zodiaco es: Capricornio");
    }
//Acuario
    if((dia>=20 && dia<=31) && mes2==1 || (dia>=1 && dia<=18) && mes2==2){
        Console.WriteLine("Su signo del zodiaco es: Acuario");
    }
//Piscis
    if((dia>=19 && dia<=31) && mes2==1 || (dia>=1 && dia<=20) && mes2==3){
        Console.WriteLine("Su signo del zodiaco es: Piscis");
    }
  
  





}

}




