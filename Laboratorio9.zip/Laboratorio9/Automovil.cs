using System.ComponentModel.DataAnnotations;
using System.Security.Cryptography;

class Automovil{
int modelo;
double precio;
string marca;
bool disponible;    
double tipoCambioDolar;
double descuentoAplicado;
double preciodolar;
public Automovil(int mod=2019, double pre=10000.00, string mar="", bool dis = false, double descuen=0){
modelo = mod;
precio = pre;
marca = mar;
disponible = dis;
descuentoAplicado = descuen;
}

public void DefinirModelo(int UnModelo){
modelo = UnModelo;
}
public void DefinirPrecio(double UnPrecio){
 precio = UnPrecio;
}
public void DefinirMarca(string UnaMarca){
    marca = UnaMarca;
}
public void DefinirTipoCambio(double UnTipoCambio){
    tipoCambioDolar = UnTipoCambio;
}
public void CambiarDisponibilidad(){
    disponible= !disponible;
}
public string MostrarDisponibilidad(){

if(disponible==true){
 return "Disponible";
}else{
return "No se encuentra disponible actualmente";
}

}
public string MostrarModelo(){
    return "El modelo es: "+modelo;
}
public string MostrarInformacion(){
    preciodolar = tipoCambioDolar * precio;
    return "Marca: "+marca+". Modelo: "+modelo+". Precio de venta: Q"+precio+". Precio en dolares: $"+preciodolar+". "+ MostrarDisponibilidad();
}
public void AplicarDescuento(double miDescuento ){
    descuentoAplicado = miDescuento;
    DefinirPrecio(precio-descuentoAplicado);


}






}