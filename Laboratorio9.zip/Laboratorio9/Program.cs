﻿class Program{
static void Main(string[] args){
Automovil objAutomovil = new Automovil();
Console.WriteLine("Ingrese modelo del auto");
objAutomovil.DefinirModelo(int.Parse(Console.ReadLine()));
Console.WriteLine("Ingrese precio del auto");
objAutomovil.DefinirPrecio(double.Parse(Console.ReadLine()));
Console.WriteLine("Ingrese Marca del auto");
objAutomovil.DefinirMarca(Console.ReadLine());
Console.WriteLine("Ingrese tipo de cambio");
objAutomovil.DefinirTipoCambio(double.Parse(Console.ReadLine()));
Console.WriteLine(objAutomovil.MostrarInformacion());
Console.WriteLine("¿Desea cambiar la disponibilidad del Auto? 1) Si  2) No");
int resp; int.TryParse(Console.ReadLine(), out resp);
if (resp == 1){
objAutomovil.CambiarDisponibilidad();
Console.WriteLine("La disponibilidad es: "+ objAutomovil.MostrarDisponibilidad());
}else{
Console.WriteLine("La disponibilidad es: "+objAutomovil.MostrarDisponibilidad());
}

Console.WriteLine("¿Desea aplicar descuento? 1) Si  2) No");
int resp2; int.TryParse(Console.ReadLine(), out resp2);
if (resp2 == 1){
Console.WriteLine("Cuál será el descuento a aplicar?");
objAutomovil.AplicarDescuento(double.Parse(Console.ReadLine()));
}

Console.WriteLine("La información del vehículo es: ");
Console.WriteLine(objAutomovil.MostrarInformacion());

}
}