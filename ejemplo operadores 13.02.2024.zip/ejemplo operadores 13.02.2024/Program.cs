﻿int a = 1;
Console.WriteLine(a);
Console.WriteLine(++a);
Console.WriteLine(a++);


int b =1;

++b;
b++;

Console.WriteLine("la variable b: " + b);

int c=1;
c+=8;
Console.WriteLine("C: " + c);

bool an=1==1;
Console.WriteLine("El valor es: " + an);

char d= 'c';

Console.WriteLine(d !='c');