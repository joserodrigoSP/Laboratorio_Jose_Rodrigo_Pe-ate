﻿namespace Laboratorio12;

public class Circulo
{

private double radio;

public  Circulo(double rad){

    this.radio = rad;
}
private double ObtenerPerimetro(){

    return (2*this.radio)*Math.PI;
}
private double ObtenerArea(){

    return (this.radio*this.radio)*Math.PI;
}
private double Obtenervolumen(){

    return ((4*Math.PI)*(this.radio*this.radio*this.radio))/3;
}
public void CalcularGeometria(ref double unPerimetro,ref double unArea, ref double unVolumen ){

unPerimetro = ObtenerPerimetro();
unArea = ObtenerArea();
unVolumen = Obtenervolumen();
}
public double MostrarArea(){
    return ObtenerArea();
}

public double MostrarPerimetro(){
    return ObtenerPerimetro();
}
public double MostrarVolumen(){
    return Obtenervolumen();
}
}
