﻿using Laboratorio12;

class Program{
static void Main(string[] args){
double resp, perimetro=0, area=0, volumen=0;
Console.WriteLine("Cuál es el radio del circulo?");
double.TryParse(Console.ReadLine(), out resp);
Circulo objcirculo= new Circulo(resp);

objcirculo.CalcularGeometria(ref perimetro, ref area, ref volumen);
Console.WriteLine($"Perimetro: {objcirculo.MostrarPerimetro() }\n Area: {objcirculo.MostrarArea()} \n Volumen: {objcirculo.MostrarVolumen()}");



}
}