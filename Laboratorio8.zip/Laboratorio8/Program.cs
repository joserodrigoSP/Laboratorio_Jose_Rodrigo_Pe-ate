﻿class Program{

    static void Main(string[] args){
        int opcion =0; 
        string entrada;
        int n= 0;
        int acum =0;
        int acummulti=1;
        int valor1=0;
    do{
        Console.WriteLine("Que desea realizar?");
        Console.WriteLine("1) sumatoria");
        Console.WriteLine("2) Factorial");
        Console.WriteLine("3) Tablas de multiplicar");
        Console.WriteLine("4) Salir ");

        entrada = Console.ReadLine();
        try{
            opcion = int.Parse(entrada);
        }catch(FormatException){
            Console.WriteLine("Error");
        }

        switch(opcion){
            case 1:
             do{
            Console.WriteLine("Sumatoria");
            Console.WriteLine("Ingrese un numero entero: ");
            int.TryParse(Console.ReadLine(), out n);
           }while(n<1);
            for(int i=0; i<=n;i++){

                Console.Write($"+{i} ");
                acum=acum+i;
            }
             Console.WriteLine("");
             Console.WriteLine("Resultado: "+acum);
             
            break;
            case 2:
                 do{
            Console.WriteLine("Factorial");
            Console.WriteLine("Ingrese un valor mayor a 0: ");
            int.TryParse(Console.ReadLine(), out n);
           }while(n<1);
           for(int i2=1; i2<=n;i2++){
            valor1=1;
                Console.Write($"{i2}* ");
                valor1++;
                acummulti=acummulti*i2;
           }
            Console.WriteLine("Resultado: "+acummulti);
            break;
            case 3:
            string titulo = "\t";
             Console.WriteLine("Tablas de multiplicar");
            for(int a=1; a<=10; a++){
                titulo += a +"\t";

            }
            Console.WriteLine(titulo);

            string fila = "";
            for(int filai = 1; filai<= 10; filai++) {   
                fila= filai + "\t";
                for(int multiplo=1; multiplo<=10;multiplo++){
                    fila += filai * multiplo + "\t";
                }

                Console.WriteLine(fila);

                
            }
       
            break;


        }



    }while(opcion!=4);



    }
}