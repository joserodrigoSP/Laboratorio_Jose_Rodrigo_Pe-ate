﻿using System.Data;

class Program
{
    static void Main(string[] args){
        int num;
        bool validarn = false;
        bool numeropositivo = false;
        do{
            Console.WriteLine("Ingrese un número mayor a 0");
            validarn = int.TryParse(Console.ReadLine(), out num);
            if(validarn){
                if(num>0){  
                    numeropositivo = true;
                      Console.WriteLine("GRACIAS");
                }
            }


        }while (!numeropositivo || !validarn);
        

    //////////  actividad 1 
    ///


    Console.WriteLine("ACTIVIDAD 7");
int A = 0;
        int B = 1;
        int C = 1;
        int i = 2;
        int resultado = 0;
        
        if(numeropositivo)
        {
            resultado = A;
            Console.Write(resultado + ", ");
            if(num > 1)
        {
            resultado += B;
            Console.Write(resultado + ", ");
            do
            {
                Console.Write(resultado + ", ");
                resultado += C;
                C = A + B;
                A = B;
                B = C;
                i++;
            }while(i < num);
        }
        }


Console.WriteLine("Tarea");

int x=0;
int a=0;
int k = 0;
int n = 0;

bool validarpositivo = false;

do{

Console.WriteLine("Inserte el valor de x:");
int.TryParse(Console.ReadLine(), out x);
Console.WriteLine("Ingrese el valor de a:");
int.TryParse(Console.ReadLine(), out a);
Console.WriteLine("Ingrese el valor de n:");
int.TryParse(Console.ReadLine(), out n);

if(a<=0 || x<=0 || n<=0 ){
    
    Console.WriteLine("Ingrese valores mayores a 0");
}else{
    validarpositivo=true;
}

}while(!validarpositivo);

Console.WriteLine("valor de x: "+ x + " valor de a: "+ a+ " valor de n: "+  n);
///////////////Insiso A tarea
///
Console.WriteLine("-----------------------------------------");

Console.WriteLine("Insiso A");
Console.WriteLine("-----------------------------------------");

double ncontador=1;
double division;
double acumulador=0.0;
do{

Console.Write($" 1/{ncontador} + " );

division= 1/ncontador;
acumulador=acumulador+division;

ncontador++;
}while(ncontador<=n);
Console.WriteLine("");

Console.WriteLine("Resultado de la sumatoria: "+ acumulador);



//////////////Inciso B tarea
///
Console.WriteLine("-----------------------------------------");
Console.WriteLine("Inciso B");
Console.WriteLine("-----------------------------------------");

double ncontador2 = 1;
double acumulador2 =0;
double result=0;
double elevar=1;

do{
    Console.Write($"1/2^{ncontador2} + ");
    elevar = elevar *2;
    result = 1 / elevar;
    
    acumulador2= acumulador2 +result;

ncontador2++;
}while(ncontador2<=n);
Console.WriteLine("");

Console.WriteLine("Resultado de la sumatoria elevado: "+ acumulador2);

//////////////Inciso C tarea
///
Console.WriteLine("-----------------------------------------");
Console.WriteLine("Inciso C");
Console.WriteLine("-----------------------------------------");

Console.WriteLine("valor de x: "+ x + " valor de a: "+ a+ " valor de n: "+  n);
double cont1=0;
double expk=0;
double valx=1;
double resta=0;
double exxp=0;
double vala=1;
double resulta =0;
//exponente de x

for(int i2=0;i2<=n; i2++){

expk= 0+i2;

resta = n - expk;

Console.Write($"(({x})^{expk})*(({a})^{resta}) +");

valx=Math.Pow(x,expk); 
exxp= Math.Pow(a,resta);
resulta= exxp * valx;
cont1= cont1+resulta;
 }
Console.WriteLine("");


Console.WriteLine("Resultado: " + cont1);






    }
}